insert into skill (id,name,description,level,user_id) values(1001L, 'Java','Java','Beginner',901234L);
insert into skill (id,name,description,level,user_id) values(1002L, 'HTML','HTML','Intermediate',903456L);
insert into skill (id,name,description,level,user_id) values(1003L, 'CSS','CSS','Beginner',904567L);
insert into skill (id,name,description,level,user_id) values(1004L, 'Spring MVC','Spring MVC','Expert',907685L);
insert into skill (id,name,description,level,user_id) values(1005L, 'Spring Boot','Spring Boot','Intermediate',904568L);