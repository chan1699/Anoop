insert into user (user_id,username,password,address,phone) values(1001L, 'Anoop','anoop123','hyderabad',8462982939L);
insert into user (user_id,username,password,address,phone) values(1002L, 'Rohith','rohith123','hyderabad',8462982739L);
insert into user (user_id,username,password,address,phone) values(1003L, 'Akshaya','akshaya123','trichy',8462982959L);
insert into user (user_id,username,password,address,phone) values(1004L, 'Bharath','bharath123','nellore',8462988939L);
insert into user (user_id,username,password,address,phone) values(1005L, 'Rahul','rahul123','nellore',8462982969L);